#include "ros/ros.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"
#include <sstream>
#include "position_controller.h"
#include "desired_positions.h"
#include "interface.h"

int main()
{
    ros::init(argc, argv, "position_control");
    ros::NodeHandle n;
    ros::Publisher pub = n.advertise<geometry_msgs::Twist>("cmd_vel_RHC", 32);

    Interface interface;
    PositionGenerator generator;
    PositionController controller;
    
    std::vector<float> current_position(3);
    std::vector<float> current_orientation(3);
    
    std::vector<float> desired_position(3);
    std::vector<float> desired_orientation(3);

    ros::Rate rate(200);

    while(ros::ok())
    {
        current_position, current_orientation = interface.get_current_state();

        interface.set_time();

        desired_position, desired_orientation = generator.get_desired_state(current_position, current_orientation);

        geometry_msgs::Twist command = controller.get_control_command(current_position, current_orientation, desired_state);

        pub.publish(command);

        rate.sleep();
    }

}
